
var express = require('express');
var router = express.Router();
var os=require('os');
var path=require('path');
var fs=require('fs');
var data11=[];
var i=0;
var c=new Array();

var database = require('../database');
var formidable = require('formidable');
const multer  = require('multer');
router.use(express.static('public'));
//const upload = multer({ dest: 'D:/login_node/public/Reserachp' });
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "D:/login_node/public/Reserachp")
  },
  filename: (req, file, cb) => {
    cb(null,file.originalname)
  },
})
const upload = multer({ storage: storage })



const storage1 = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "D:/NODE_SRP/login_node (5)-today/login_node2/public")
  },
  filename: (req, file, cb) => {
    cb(null,file.originalname)
  },
})
const upload1 = multer({ storage: storage1 })



var ss;
var ss1;
var d;
var dataa;
var nn;

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express', session : req.session });
  session=req.session;
});
router.get('/adminindex', function(req, res, next) {
//ss=req.session;
  res.render('adminindex', { title: 'Express', session : req.session });
  
});
router.get('/reindex', function(req, res, next) {
  //ss=req.session;
    res.render('researchscholarindex', { title: 'Express', session : req.session });
    
  });
  router.get('/viewg', function(req, res, next) {
    //ss=req.session;
      res.render('vgraph', { title: 'Express', session : req.session });
      
    });
    router.get('/chart.ejs', function(req, res, next) {
      //ss=req.session;
        res.render('chart', { title: 'Express', session : req.session });
        
      });    
router.get('/pevent', function(req, res, next) {
  res.render('postevents', { title: 'Express', session : req.session });
});

router.get('/placem', function(req, res, next) {
  res.render('placement', { title: 'Express', session : req.session });
});
router.get('/inter', function(req, res, next) {
  res.render('intern', { title: 'Express', session : req.session });
});

router.get('/signup', function(req, res, next) {
    res.render('signup');
  });
  router.post('/poste', function(req, res, next) {
  
    
    const userDetails=req.body;
   
    
    var sql = 'INSERT INTO events SET ?';
    database.query(sql, userDetails,function (err, data) { 
        if (err) throw err;
           console.log("User dat is inserted successfully "); 
    });
    res.render('postevents');
    //res.send('Insertion sucessful');  // redirect to user form page after inserting the data
}); 
router.post('/place', function(req, res, next) {
  
    
  const userDetails=req.body;
 
  
  var sql = 'INSERT INTO placements SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("Placement data is inserted successfully "); 
  });
  res.render('adminindex');
  //res.send('Insertion sucessful');  // redirect to user form page after inserting the data
}); 

router.post('/inte', function(req, res, next) {
  
    
  const userDetails=req.body;
 
  
  var sql = 'INSERT INTO intern SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("Intern data is inserted successfully "); 
  });
  res.render('adminindex');
  //res.send('Insertion sucessful');  // redirect to user form page after inserting the data
}); 
  router.get('/event', function (req, res, next) {
    database.query('SELECT * FROM events', function (err, rows) {
      if (err) {
        req.flash('error', err)
        res.render('events', { data: '' })
      } else {
        res.render('events', { data: rows })
      }
    })
  })
  router.post('/upe', function(req, res, next) {
    var id= req.body.sno;
      const updateData=req.body;
      var sql = `UPDATE events SET ? WHERE sno= ?`;
      database.query(sql, [updateData, id], function (err, data) {
      if (err) throw err;
      console.log(" record(s) updated");
    });
    res.send("updatedd!")
    res.end();
   
  });
    
  
  router.post('/sign',function(request,response,next){
    var e = request.body.user_email_address;
    var p=request.body.user_password;
    if(e && p)
    {
        query=`Select * from user_login where user_email="${e}"`;
        database.query(query,function(error,data){
            var count=0;
            if(data.length > 0)
            {
                for(count = 0; count < data.length; count++)
                {
                    
                    }
                    if(count>0)
                    {response.send('Exists');
                }
                if(count==0)
                {
                    const query1=`insert into user_login (user_email, user_password) values ('${e}', '${p}')`;
                    database.query(
                        "insert into user_login set ?",
                        { user_email: e, user_password: p},
                        (error, result) => {
                          if (error) {
                            console.log(error);
                          }
                        else{ 
response.send('1 record inserted');  
}
                    });
                    
                        
                }
                    /*if(count==data.length)
                    {
                        
                        query1=`insert into  user_login(user_email) values("$e")`;
                        database.query(query1,function(error,data){
                            });
                            response.redirect("/login")
                        
                    
                    }*/

     } response.end();
    }
     );
    }
  })
  

router.post('/login', function(request, response, next){

    var user_email_address = request.body.user_email_address;

    var user_password = request.body.user_password;
    ss1=request.session;

    if(user_email_address && user_password)
    {
        query = `
        SELECT * FROM user_login 
        WHERE user_email = "${user_email_address}"
        `;
        query1 = `
        SELECT * FROM researchlogin
        WHERE user_email = "${user_email_address}"
        `;

        database.query(query, function(error, data){

            if(data.length > 0)
            {
                for(var count = 0; count < data.length; count++)
                {
                    if(data[count].user_password == user_password)
                    {
                        request.session.user_id = data[count].user_id;
                        request.session.email=data[count].user_email;

                        response.redirect("/");
                    }
                    else
                    {
                        response.send('Incorrect Password');
                    }
                }
            }
            else 
            {
                
              
              response.send('Incorrect Email Address');
            }
            response.end();
        });
    }
    else
    {
        response.send('Please Enter Email Address and Password Details');
        response.end();
    }

});

router.post('/rlogin', function(request, response, next){

  var user_email_address = request.body.user_email_address;

  var user_password = request.body.user_password;
  ss1=request.session;

  if(user_email_address && user_password)
  {
      
      query = `
      SELECT * FROM researchlogin
      WHERE user_email = "${user_email_address}"
      `;

      database.query(query, function(error, data){

          if(data.length > 0)
          {
              for(var count = 0; count < data.length; count++)
              {
                  if(data[count].user_password == user_password)
                  {
                      request.session.user_id = data[count].user_id;
                      request.session.email=data[count].user_email;

                      response.render("researchscholarindex",{session:ss1});
                  }
                  else
                  {
                      response.send('Incorrect Password');
                  }
              }
          }
          else 
          {
              
            
            response.send('Incorrect Email Address');
          }
          response.end();
      });
  }
  else
  {
      response.send('Please Enter Email Address and Password Details');
      response.end();
  }

});


router.post('/alogin', function(request, response, next){

  var user_email_address = request.body.user_email_address;

  var user_password = request.body.user_password;
  ss1=request.session;

  if(user_email_address && user_password)
  {
      query = `
      SELECT * FROM adminlogin 
      WHERE aemail = "${user_email_address}"
      `;

      database.query(query, function(error, data){

          if(data.length > 0)
          {
              for(var count = 0; count < data.length; count++)
              {
                  if(data[count].apassword == user_password)
                  {
                      request.session.sno = data[count].user_id;
                      request.session.email=data[count].aemail;
                      request.session.who=data[count].who;

                      response.render("adminindex",{session:ss1});
                  }
                  else
                  {
                      response.send('Incorrect Password');
                  }
              }
          }
          else
          {
              response.send('Incorrect Email Address');
          }
          response.end();
      });
  }
  else
  {
      response.send('Please Enter Email Address and Password Details');
      response.end();
  }

});


router.get('/logout', function(request, response, next){

    request.session.destroy();

    response.redirect("/");

});
router.get('/updateevents', function (req, res, next) {
   
  database.query('SELECT * FROM events', function (err, rows) {
    
    if (err) {
      req.flash('error', err)
      res.render('updateevents', { data: '',title: 'Express', session : ss1 })
    } else {
      res.render('updateevents', { data: rows , title: 'Express', session: ss1 })
    }
  })
})
router.get('/postq', function (req, res, next) {
  var e=ss1.email;
  var sql = "SELECT * FROM answers where email=?";
  database.query(sql,[e],function(err, rows, fields) {
    if (err) {
      req.flash('error', err)
      res.render('postquestion', { data: '' , title: 'Express', ss1 : ss1 })
    } else {
      res.render('postquestion', { data: rows , title: 'Express', ss1 : ss1 })
    }
  })
})
/*router.get('/postq', function(req, res, next) {
  res.render('postquestion',{ title: 'Express', ss1 : ss1 });
});*/
router.post('/pq', function (req, res, next) {
   
  const userDetails=req.body;
   
    
  var sql = 'INSERT INTO questions SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  res.send('postedd!');
  
})
router.get('/ansq', function (req, res, next) {
  var e=ss1.email;
  var sql = "SELECT * FROM questions where email<>?";
  database.query(sql,[e],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('answerqs', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('answerqs', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})
router.post('/aq', function (req, res, next) {
   
  const userDetails=req.body;
  var sno=req.body.sno;
  var sql1="Update questions set ans='done' where sno=?"
  database.query(sql1,[sno],function(err,data){

  });
   
    
  var sql = 'INSERT INTO answers SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  res.send("Answered!");
  
})
router.get('/allq', function (req, res, next) {
  var e=ss1.email;
  var sql = "SELECT * FROM answers";
  database.query(sql,function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('allqs', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('allqs', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})

router.get('/aevent', function (req, res, next) {
  //var e=ss1.email;
  var sql = "SELECT * FROM events";
  database.query(sql,function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('aevents', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('aevents', { data: rows , title: 'Express', ss1: ss1})
    }
  })
})
router.post('/adel', function (req, res, next) {
  var e=req.body.sno;
  var sql = "DELETE FROM events where sno=?";
  database.query(sql,[e],function(err, rows1, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.send('error');
    } else {
      res.render("del");
    }
  })
})

router.get('/unansq', function (req, res, next) {
  var e=ss1.email;
  var sql = "SELECT * FROM questions where ans<>'done' and email=?";
  database.query(sql,[e],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('unanswered', { data: rows , title: 'Express', ss1: ss1})
    }
  })
})
router.get('/delq', function (req, res, next) {
   
  database.query('SELECT * FROM questions', function (err, rows) {
    
    if (err) {
      
      res.render('adelete', { data: '',title: 'Express', session : ss1 })
    } else {
      res.render('adelete', { data: rows , title: 'Express', session: ss1 })
    }
  })
})
router.post('/adelqs', function (req, res, next) {
  var sno=req.body.sno;
   
  var sql = "Delete FROM questions where sno=?";
  database.query(sql,[sno],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.send("Deleted!!");
    }
  })
})
router.post('/view', function (req, res, next) {
  var sno=req.body.sno;
   
  var sql = "select * from answers where sno=?";
  database.query(sql,[sno],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('viewqs', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})

router.post('/adelans', function (req, res, next) {
  var sno1=req.body.ansby;
  var sno2=req.body.sno;
  var sno3=req.body.ans;
  
  
   
   
  var sql ="update answers set ans='This was deleted by admin' where sno=? and ansby=? and ans=?";
  database.query(sql,[sno2,sno1,sno3],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.send('sent');
    }
  })
  
   

})
router.get('/uploading', function(req, res, next) {
  res.render('rp', { title: 'Express', ss1 : ss1 });
});
router.post("/research1", upload.single("myFile"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{name:req.body.name,mail:req.body.mail,path:path,papername:req.body.papername,description:req.body.description}];

   
    
  var sql = 'INSERT INTO papers SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded"+" <a href='/uploading' class='btn btn-primary'>Backk</a>");
  
  
});



router.get('/vrp', function(req, res) {
  var sql = "select * from papers";
  database.query(sql,function(err, rows, fields) {
   
 
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('viewpapers', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
});

router.get('/avrp', function(req, res) {
  var sql = "select * from papers";
  database.query(sql,function(err, rows, fields) {
   
  
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('viewpapersadmin', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})
 
  
router.post('/adminviewrp', function(req, res) {
  filee=req.body.path;

  res.sendFile(filee);
})



router.post('/adminrpdel', function(req, res) {
  p=req.body.path;
  var sql = "DELETE FROM papers where path=?";
  database.query(sql,[p],function(err, rows1, fields) {
   
    
    if (err) {
      
      res.send('error');
    } else {
      res.send("Deleted");
    }
  });

  
})
router.post('/viewrp', function(req, res) {
  filee=req.body.path;

  res.sendFile(filee);
})
router.get('/createstudyg', function(req, res) {
  
      res.render('cstudygr', { title: 'Express', ss1: ss1 })
    
  })

  router.post('/csg', function(req, res, next) {
  
    
    const userDetails=req.body;
    
   
    
    var sql = 'INSERT INTO studygroups SET ?';
    database.query(sql, userDetails,function (err, data) { 
        if (err) throw err;
           console.log("User dat is inserted successfully "); 
    });
    res.render('cstudygr', { title: 'Express', ss1: ss1 });
    //res.send('Insertion sucessful');  // redirect to user form page after inserting the data
}); 
router.get('/joingrp', function(req, res) {
e=ss1.email;
z=0;
  var sql = "select * from studygroups where createdby<>? and no<>?";
  database.query(sql,[e,z],function(err, rows, fields) {
   
  
    
    if (err) {
      
      //res.render('unanswered', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('joinsgr', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})
router.post('/join', function(req, res, next) {
  
    e=ss1.email;
    sgno=req.body.sno;
    var mm=0;
    console.log(sgno);
    d=sgno;
    nn=req.body.name;
    console.log(d);
    
  const userDetails=req.body;
  var sqll="Select * from meeting where sgno=? order by sno desc";
  database.query(sqll,[d],function(err,dataa){

  })
  
  var sql1="Select * from joinedgroups where joinedby=? and sno=?";
  database.query(sql1, [e,sgno],function (err, data) { 
    
    if(data.length!=0)
   { mm=1;
       console.log("aldready there ");
      //res.send("aldreafy there");
      res.render('welcomesg', {d:sgno,title: 'Express', ss1: ss1,data:data,nn:nn });} 
       else
       {
        var sql = 'INSERT INTO joinedgroups SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  m=req.body.sno;
  n=req.body.no;
  n--;
  console.log(n);
  console.log(m);
   
  var sql2 ="update studygroups set no=? where sno=?";
  database.query(sql2,[n,m],function(err, rows) {
    console.log("updated");
    console.log(n);
   
       });
  res.render('welcomesg', {d:sgno,title: 'Express', ss1: ss1,data:data,nn:nn });
  res.end();
  
  
       }

      
      
});
});
router.get('/vsg', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from joinedgroups where joinedby=?";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('sg', { data:data,title: 'Express', ss1: ss1 })})

})
router.post('/viewsg', function(req, res) {
  e=ss1.email;
  na=req.body.name;
  d=req.body.sno;
  nn=na;
  console.log(nn);
  var sqll="Select * from meeting where sgno=? order by sno desc";
  database.query(sqll,[d],function(err,data){
    res.render('welcomesg', {d:d,title: 'Express', ss1: ss1,data:data,nn:nn })

  })
  
  
  //res.render('welcomesg', {d:d,title: 'Express', ss1: ss1,data:data })
})
  router.get('/vsg', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from joinedgroups where joinedby=?";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('sg', { d:d,data:data,title: 'Express', ss1: ss1,nn:nn })})

})


router.get('/bookpub', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from booksfaculty";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('bookspublished', { data:data,title: 'Express', ss1: ss1 })})

})



router.post('/booksp', function(req, res, next) {
  
    
  const userDetails=req.body;
 
  
  var sql = 'INSERT INTO booksfaculty SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  res.send('done');
  //res.send('Insertion sucessful');  // redirect to user form page after inserting the data
}); 



router.post('/ubooksp', function(req, res, next) {
  var id= req.body.sno;
    const updateData=req.body;
    var sql = `UPDATE booksfaculty SET ? WHERE sno= ?`;
    database.query(sql, [updateData, id], function (err, data) {
    if (err) throw err;
    console.log(" record(s) updated");
  });
  res.send("updatedd!")
  res.end();
 
});

router.post('/dbooksp', function(req, res, next) {
  var id= req.body.sno;
    const updateData=req.body;
    var sql = `delete from booksfaculty WHERE sno= ?`;
    database.query(sql, [id], function (err, data) {
    if (err) throw err;
    console.log(" record(s) updated");
  });
  res.send("Deleted!")
  res.end();
 
});

router.post('/dgal', function(req, res, next) {
  var id= req.body.sno;
    const updateData=req.body;
    var sql = `delete from gallery WHERE sno= ?`;
    database.query(sql, [id], function (err, data) {
    if (err) throw err;
    console.log(" record(s) updated");
  });
  res.send("Deleted!")
  res.end();
 
});


router.get('/gal', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from gallery";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('gallery', { data:data,title: 'Express', ss1: ss1 })})

})

router.get('/rv1', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from rvedio";
  database.query(sql1, [e],function (err, data1) { 
    for(var j=0;j<data1.length;j++)
    {c.push(data1[j].path);
      

    }
   
   
  res.render('reasearchv', { data:data1,title: 'Express', ss1: ss1 })})

})



router.post("/gallery1", upload1.single("gal"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{description:req.body.description,title:req.body.title,path:req.file.filename}];

   
    
  var sql = 'INSERT INTO gallery SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded");
  
  
});


router.post("/gallery2", upload1.single("gal2"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{name:req.body.name,pathh:req.file.filename,year:req.body.year}];

   
    
  var sql = 'INSERT INTO activities SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded");
  
  
});


router.post("/research2", upload1.single("myFile"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{vedioname:req.body.vedioname,description:req.body.description,name:req.body.name,mail:req.body.mail,path:req.file.filename}];

   
    
  var sql = 'INSERT INTO rvedio SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded"+" <a href='/uploading' class='btn btn-primary'>Backk</a>");
  
  
});

router.get('/adminviewrv', function(req, res) {
  //console.log("hi");
 // range=req.headers.range;
  //console.log(range);
  //const filee=req.body.path;
//const st=fs.readFile(filee,(err,st)=>{if(err)res.end("error");res.set("Content-Type","video/mp4");res.send(st);});
  //stream.on("open",()=>{res.set("Content-type")})
  //var ytdl = require('ytdl-core');    
  //var url = filee;
   // ytdl(url).pipe(res);
 /* const vsize=fs.statSync(filee).size;
  const CHUNK_SIZE = 10 ** 6; // 1MB
  range=""+range;
const start = Number(range.replace(/\D/g, ""));
const end = Math.min(start + CHUNK_SIZE, vsize - 1);
const contentLength = end - start + 1;

const headers = {
  "Content-Range": `bytes ${start}-${end}/${vsize}`,
  "Accept-Ranges": "bytes",
  "Content-Length": contentLength,
  "Content-Type": "video/mp4",
};

res.writeHead(206, headers);
res.send(filee)

const videoStream = fs.createReadStream(filee, { start, end });
   */
  

  //res.sendFile(filee);
  const range = req.headers.range
  console.log(c);
  var bb=0;
  console.log(i);
    const videoPath =c[0];
    i++;
    console.log(i);
    
    //i++;
    //'D:/NODE_SRP/login_node (5)-today/login_node2/public/HTML Forms-by Shivaani S (2020115082) - Google Chrome 2021-07-13 11-23-50.mp4';
    
    const videoSize = fs.statSync(videoPath).size
    const chunkSize = 1 * 1e6;
    const start = Number(range.replace(/\D/g, ""))
    const end = Math.min(start + chunkSize, videoSize - 1)
    const contentLength = end - start + 1;
    const headers = {
        "Content-Range": `bytes ${start}-${end}/${videoSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": contentLength,
        "Content-Type": "video/mp4"
    }
    res.writeHead(206, headers)
    const stream = fs.createReadStream(videoPath, {
        start,
        end
    })
    stream.pipe(res);
    //res.end();
    
    
    //i++;
})


router.get('/gale', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from activities";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('activities', { data:data,title: 'Express', ss1: ss1 })})

})

router.get('/viewact', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from activities";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('studentactivities', { data:data,title: 'Express', ss1: ss1 })})

})


router.post('/vact', function(req, res) {
  e=ss1.email;
  var data1;
  ee=req.body.name;
  yy=req.body.year;
  console.log(ee);
  console.log(req.body.year);

  var sql1="Select * from activities where name=? and year=?";
  database.query(sql1, [ee,yy],function (err, data) { 
   
  res.render('vstudentactivities', { data:data,title: 'Express', ss1: ss1 })})

})

router.get('/postqsg', function(req, res) {
  e=ss1.email;
  var data1;
  var sql = "SELECT * FROM answersg where email=? and sgno=?";
  console.log(d);
  database.query(sql,[e,d],function(err, rows, fields) {
  

 
   
res.render('postqcg', { d:d,data:rows,title: 'Express', ss1: ss1 })})

})

router.get('/allqsg', function(req, res) {
  var e=ss1.email;
  var sql = "SELECT * FROM answersg where sgno=?";
  database.query(sql,[d],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('allqcg', {d:d, data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('allqcg', { d:d,data: rows , title: 'Express', ss1: ss1 })
    }
  })

})

router.get('/ansqsg', function (req, res, next) {
  var e=ss1.email;
  var sql = "SELECT * FROM questionsg where email<>? and sgno=?";
  database.query(sql,[e,d],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('anscg', { d:d,data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('anscg', { d:d,data: rows , title: 'Express', ss1: ss1 })
    }
  })
})

router.get('/enterpla', function(req, res) {
  var e=ss1.email;
  var sql = "SELECT * FROM placements";
  database.query(sql,[d],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('enterpla', {d:d, data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('enterpla', { d:d,data: rows , title: 'Express', ss1: ss1 })
    }
  })

})

router.get('/enterin', function(req, res) {
  var e=ss1.email;
  var sql = "SELECT * FROM intern";
  database.query(sql,[d],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      res.render('enterin', {d:d, data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('enterin', { d:d,data: rows , title: 'Express', ss1: ss1 })
    }
  })

})

router.post('/pqsg', function (req, res, next) {
   
  const userDetails=req.body;
   
    
  var sql = 'INSERT INTO questionsg SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  res.send('postedd!');
  
})


router.post('/aqsg', function (req, res, next) {
   
  const userDetails=req.body;
  var sno=req.body.sno;
  var sql1="Update questionsg set ans='done' where sno=?"
  database.query(sql1,[sno],function(err,data){

  });
   
    
  var sql = 'INSERT INTO answersg SET ?';
  database.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });
  res.send("Answered!");
  
})

router.get('/allqsg', function (req, res, next) {
  var e=ss1.email;
  var d1=d;
  var sql = "SELECT * FROM answersg where sgno=?";
  database.query(sql,[d1],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('allqcg', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('allqcg', { data: rows , title: 'Express', ss1: ss1 })
    }
  })
})

router.get('/unansqsg', function (req, res, next) {
  var e=ss1.email;
  var d1=d;
  var sql = "SELECT * FROM questionsg where ans<>'done' and email=? and sgno=?";
  database.query(sql,[e,d],function(err, rows, fields) {
   
  //database.query('SELECT * FROM questions where email!=?', function (err,[e],rows) {
    
    if (err) {
      
      res.render('unanscg', { data: '',title: 'Express', ss1: ss1 })
    } else {
      res.render('unanscg', { data: rows , title: 'Express', ss1: ss1})
    }
  })
})


router.get('/vmsg', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from studygroups where createdby=?";
  database.query(sql1, [e],function (err, data) { 
   
  res.render('sg', { data:data,title: 'Express', ss1: ss1 })})

})



router.post('/meet', function(req, res, next) {
  var id= req.body.sgno;
    const updateData=req.body;
    var sql = `INSERT INTO meeting SET ?`;
    database.query(sql, updateData, function (err, data) {
    if (err) throw err;
    console.log(" record(s) inserted");
  });
  res.send("Posted!")
  res.end();
 
});


router.get('/matu', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from materialss where sgno=?";
  database.query(sql1, [d],function (err, data) { 
   
  res.render('mat', { data:data,title: 'Express', ss1: ss1,d:d })})

})


router.post("/m", upload.single("myFile"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{description:req.body.description,pathh:path,mail:req.body.mail,sgno:req.body.sgno}];

   
    
  var sql = 'INSERT INTO materialss SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded"+" <a href='/uploading' class='btn btn-primary'>Backk</a>");
  
  
});

router.get('/vgall', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from gallery";
  database.query(sql1, [d],function (err, data) { 
   
  res.render('viewgal', { data:data,title: 'Express', ss1: ss1,d:d })})

})

router.get('/vbp', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from booksfaculty";
  database.query(sql1, [d],function (err, data) { 
   
  res.render('viewbooksp', { data:data,title: 'Express', ss1: ss1,d:d })})

})

router.post("/achieve1", upload.single("myFile1"), (req, res) => {
  // Stuff to be added later
  console.log(req.file);
  path= req.file.destination+'/'+req.file.filename;
  
  arrayyy=[{acname:req.body.acname,description:req.body.description,mail:req.body.mail,path:path}];

   
    
  var sql = 'INSERT INTO achievements SET ?';
  database.query(sql, arrayyy,function (err, data) { 
      if (err) throw err;
         console.log("User dat is inserted successfully "); 
  });

  
  res.send("Uploaded"+" <a href='/uploading' class='btn btn-primary'>Backk</a>");
  
  
});
router.get('/vach', function(req, res) {
  e=ss1.email;
  var data1;
  

  var sql1="Select * from achievements";
  database.query(sql1, [d],function (err, data) { 
   
  res.render('addachieve', { data:data,title: 'Express', ss1: ss1,d:d })})

})

router.get('/adminplace', function(req, res) {
  e=ss1.email;
  var data1;
  mm='a';
  

  var sql1="Select * from placements where status <> ?";
  database.query(sql1, [mm],function (err, data) { 
   
  res.render('approveplace', { data:data,title: 'Express', ss1: ss1,d:d })})

})

router.post('/dplace', function (req, res, next) {
   
  const userDetails=req.body;
   ssnnoo=req.body.sno;
    
  var sql = 'Delete from placements where sno=?';
  database.query(sql,[ssnnoo],function (err, data) { 
      if (err) throw err;
         console.log("Errorrr!"); 
  });
  res.send('dONE not approveddd');
  
})


router.post('/aplace', function (req, res, next) {
   
  const userDetails=req.body;
   ssnnoo=req.body.sno;
    
   var sql = `UPDATE placements SET status='a' WHERE sno= ?`;
  database.query(sql,[ssnnoo],function (err, data) { 
      if (err) throw err;
         console.log("Errorrr!"); 
  });
  res.send('approveddd');
  
})


router.get('/adminintern', function(req, res) {
  e=ss1.email;
  var data1;
  mm='a';
  

  var sql1="Select * from intern where status <> ?";
  database.query(sql1, [mm],function (err, data) { 
   
  res.render('approveintern', { data:data,title: 'Express', ss1: ss1,d:d })})

})

router.post('/dintern', function (req, res, next) {
   
  const userDetails=req.body;
   ssnnoo=req.body.sno;
    
  var sql = 'Delete from intern where sno=?';
  database.query(sql,[ssnnoo],function (err, data) { 
      if (err) throw err;
         console.log("Errorrr!"); 
  });
  res.send('dONE not approveddd');
  
})


router.post('/aintern', function (req, res, next) {
   
  const userDetails=req.body;
   ssnnoo=req.body.sno;
    
   var sql = `UPDATE intern SET status='a' WHERE sno= ?`;
  database.query(sql,[ssnnoo],function (err, data) { 
      if (err) throw err;
         console.log("Errorrr!"); 
  });
  res.send('approveddd');
  
})



module.exports = router;


