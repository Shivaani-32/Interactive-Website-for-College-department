<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Login System in Node.js Express</title>

    <style>
        .ali {
            text-align: center;
        }

        .blu {
            color: rgb(11, 11, 125);
        }

        .log{
            background-color: rgb(3, 3, 99);
            color: orange;
            font-size: 25px;
        }

        .ora {
            color: rgb(182, 122, 11);
        }

        .headi{
            text-align: center;
            font-family: 'Times New Roman', Times, serif;
            font-size: 45px;
            text-decoration: double;
            color: rgb(11, 11, 125);
        }

        .but{
            color: orange;
        }

        p{
                text-align:center;
                font-size: 20px;
            }
    </style>

    <div class="container pt-0 ali">

        <h1 class="blu"> DEPARTMENT OF INFORMATION SCIENCE AND TECHNOLOGY </h1>
        <h3 class="ora"> ANNA UNIVERSITY </h3>
        <br>
    </div>
</head>

        
    <body>
  
        <nav class="navbar navbar-expand-sm bg-dark justify-content-center">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link link-light" href="/event">Events</a>
              </li>
              <li class="nav-item">
                <a class="nav-link link-light" href="/uploading">Add Achievements</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle link-light" href="#" role="button" data-bs-toggle="dropdown">Discussion</a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="/allqsg">View</a></li>
                    <li><a class="dropdown-item btn btn-primary" href="/postqsg">Ask Question</a></li>
                    <li><a class="dropdown-item" href="/ansqsg">Answer Question</a></li>
                    <li><a class="dropdown-item" href="/unansqsg">View My Unanswered Question</a></li>

                </ul>
            </li>
              <li class="nav-item">
                <a class="nav-link link-light" href="/logout">Log Out</a>
              </li>
            </ul>
          </nav>
          <br>
       

        <% if(data.length){ for(var i = 0; i< data.length; i++) {%>
            
            <p class="blu"><%= data[i].q%>
             -  <%= data[i].email%></p>
              
              <p class="ora"><%= data[i].ans%>
              -  <%= data[i].ansby%></p>
              
              <hr>
            <% } }else{ %>
            
              <p>No data ever existed.</p>
           
            <% } %>
    </body>
</html>